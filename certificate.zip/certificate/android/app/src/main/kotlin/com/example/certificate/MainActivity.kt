package com.example.certificate

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
